/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_error";
exports.ids = ["pages/_error"];
exports.modules = {

/***/ "./node_modules/@sentry/webpack-plugin/src/sentry-webpack.module.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@sentry/webpack-plugin/src/sentry-webpack.module.js ***!
  \**************************************************************************/
/***/ (() => {

eval("const _global = (typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {}); _global.SENTRY_RELEASE={id:\"development\"};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvQHNlbnRyeS93ZWJwYWNrLXBsdWdpbi9zcmMvc2VudHJ5LXdlYnBhY2subW9kdWxlLmpzLmpzIiwibWFwcGluZ3MiOiJBQUFBLDBJQUEwSSxHQUFHLHdCQUF3QiIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYi8uL25vZGVfbW9kdWxlcy9Ac2VudHJ5L3dlYnBhY2stcGx1Z2luL3NyYy9zZW50cnktd2VicGFjay5tb2R1bGUuanM/Y2IyMyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBfZ2xvYmFsID0gKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gd2luZG93IDogdHlwZW9mIGdsb2JhbCAhPT0gJ3VuZGVmaW5lZCcgPyBnbG9iYWwgOiB0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgPyBzZWxmIDoge30pOyBfZ2xvYmFsLlNFTlRSWV9SRUxFQVNFPXtpZDpcImRldmVsb3BtZW50XCJ9OyJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/@sentry/webpack-plugin/src/sentry-webpack.module.js\n");

/***/ }),

/***/ "./pages/_error.js":
/*!*************************!*\
  !*** ./pages/_error.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ \"react/jsx-runtime\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/error */ \"next/error\");\n/* harmony import */ var next_error__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_error__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _sentry_nextjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @sentry/nextjs */ \"@sentry/nextjs\");\n/* harmony import */ var _sentry_nextjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sentry_nextjs__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst MyError = ({ statusCode , hasGetInitialPropsRun , err  })=>{\n    if (!hasGetInitialPropsRun && err) {\n        // getInitialProps is not called in case of\n        // https://github.com/vercel/next.js/issues/8592. As a workaround, we pass\n        // err via _app.js so it can be captured\n        _sentry_nextjs__WEBPACK_IMPORTED_MODULE_2__.captureException(err);\n    // Flushing is not required in this case as it only happens on the client\n    }\n    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_error__WEBPACK_IMPORTED_MODULE_1___default()), {\n        statusCode: statusCode,\n        __source: {\n            fileName: \"/Users/ktech/Downloads/training-task-2-main/web/pages/_error.js\",\n            lineNumber: 13,\n            columnNumber: 10\n        },\n        __self: undefined\n    }));\n};\nMyError.getInitialProps = async (context)=>{\n    const errorInitialProps = await next_error__WEBPACK_IMPORTED_MODULE_1___default().getInitialProps(context);\n    const { res , err , asPath  } = context;\n    // Workaround for https://github.com/vercel/next.js/issues/8592, mark when\n    // getInitialProps has run\n    errorInitialProps.hasGetInitialPropsRun = true;\n    // Returning early because we don't want to log 404 errors to Sentry.\n    if ((res === null || res === void 0 ? void 0 : res.statusCode) === 404) {\n        return errorInitialProps;\n    }\n    // Running on the server, the response object (`res`) is available.\n    //\n    // Next.js will pass an err on the server if a page's data fetching methods\n    // threw or returned a Promise that rejected\n    //\n    // Running on the client (browser), Next.js will provide an err if:\n    //\n    //  - a page's `getInitialProps` threw or returned a Promise that rejected\n    //  - an exception was thrown somewhere in the React lifecycle (render,\n    //    componentDidMount, etc) that was caught by Next.js's React Error\n    //    Boundary. Read more about what types of exceptions are caught by Error\n    //    Boundaries: https://reactjs.org/docs/error-boundaries.html\n    if (err) {\n        _sentry_nextjs__WEBPACK_IMPORTED_MODULE_2__.captureException(err);\n        // Flushing before returning is necessary if deploying to Vercel, see\n        // https://vercel.com/docs/platform/limits#streaming-responses\n        await _sentry_nextjs__WEBPACK_IMPORTED_MODULE_2__.flush(2000);\n        return errorInitialProps;\n    }\n    // If this point is reached, getInitialProps was called without any\n    // information about what the error might be. This is unexpected and may\n    // indicate a bug introduced in Next.js, so record it in Sentry\n    _sentry_nextjs__WEBPACK_IMPORTED_MODULE_2__.captureException(new Error(`_error.js getInitialProps missing data at path: ${asPath}`));\n    await _sentry_nextjs__WEBPACK_IMPORTED_MODULE_2__.flush(2000);\n    return errorInitialProps;\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyError);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZXJyb3IuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBMkM7QUFDSDtBQUV4QyxLQUFLLENBQUNFLE9BQU8sSUFBSSxDQUFDLENBQUNDLFVBQVUsR0FBRUMscUJBQXFCLEdBQUVDLEdBQUcsRUFBQyxDQUFDLEdBQUssQ0FBQztJQUMvRCxFQUFFLEdBQUdELHFCQUFxQixJQUFJQyxHQUFHLEVBQUUsQ0FBQztRQUNsQyxFQUEyQztRQUMzQyxFQUEwRTtRQUMxRSxFQUF3QztRQUN4Q0osNERBQXVCLENBQUNJLEdBQUc7SUFDM0IsRUFBeUU7SUFDM0UsQ0FBQztJQUVELE1BQU0sc0VBQUVMLG1EQUFrQjtRQUFDRyxVQUFVLEVBQUVBLFVBQVU7Ozs7Ozs7O0FBQ25ELENBQUM7QUFFREQsT0FBTyxDQUFDSyxlQUFlLFVBQVVDLE9BQU8sR0FBSyxDQUFDO0lBQzVDLEtBQUssQ0FBQ0MsaUJBQWlCLEdBQUcsS0FBSyxDQUFDVCxpRUFBa0MsQ0FBQ1EsT0FBTztJQUUxRSxLQUFLLENBQUMsQ0FBQyxDQUFDRSxHQUFHLEdBQUVMLEdBQUcsR0FBRU0sTUFBTSxFQUFDLENBQUMsR0FBR0gsT0FBTztJQUVwQyxFQUEwRTtJQUMxRSxFQUEwQjtJQUMxQkMsaUJBQWlCLENBQUNMLHFCQUFxQixHQUFHLElBQUk7SUFFOUMsRUFBcUU7SUFDckUsRUFBRSxHQUFFTSxHQUFHLGFBQUhBLEdBQUcsS0FBSEEsSUFBSSxDQUFKQSxDQUFlLEdBQWZBLElBQUksQ0FBSkEsQ0FBZSxHQUFmQSxHQUFHLENBQUVQLFVBQVUsTUFBSyxHQUFHLEVBQUUsQ0FBQztRQUM1QixNQUFNLENBQUNNLGlCQUFpQjtJQUMxQixDQUFDO0lBRUQsRUFBbUU7SUFDbkUsRUFBRTtJQUNGLEVBQTJFO0lBQzNFLEVBQTRDO0lBQzVDLEVBQUU7SUFDRixFQUFtRTtJQUNuRSxFQUFFO0lBQ0YsRUFBMEU7SUFDMUUsRUFBdUU7SUFDdkUsRUFBc0U7SUFDdEUsRUFBNEU7SUFDNUUsRUFBZ0U7SUFFaEUsRUFBRSxFQUFFSixHQUFHLEVBQUUsQ0FBQztRQUNSSiw0REFBdUIsQ0FBQ0ksR0FBRztRQUUzQixFQUFxRTtRQUNyRSxFQUE4RDtRQUM5RCxLQUFLLENBQUNKLGlEQUFZLENBQUMsSUFBSTtRQUV2QixNQUFNLENBQUNRLGlCQUFpQjtJQUMxQixDQUFDO0lBRUQsRUFBbUU7SUFDbkUsRUFBd0U7SUFDeEUsRUFBK0Q7SUFDL0RSLDREQUF1QixDQUNyQixHQUFHLENBQUNZLEtBQUssRUFBRSxnREFBZ0QsRUFBRUYsTUFBTTtJQUVyRSxLQUFLLENBQUNWLGlEQUFZLENBQUMsSUFBSTtJQUV2QixNQUFNLENBQUNRLGlCQUFpQjtBQUMxQixDQUFDO0FBRUQsaUVBQWVQLE9BQU8sRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYi8uL3BhZ2VzL19lcnJvci5qcz8yMDEwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBOZXh0RXJyb3JDb21wb25lbnQgZnJvbSAnbmV4dC9lcnJvcic7XG5pbXBvcnQgKiBhcyBTZW50cnkgZnJvbSAnQHNlbnRyeS9uZXh0anMnO1xuXG5jb25zdCBNeUVycm9yID0gKHsgc3RhdHVzQ29kZSwgaGFzR2V0SW5pdGlhbFByb3BzUnVuLCBlcnIgfSkgPT4ge1xuICBpZiAoIWhhc0dldEluaXRpYWxQcm9wc1J1biAmJiBlcnIpIHtcbiAgICAvLyBnZXRJbml0aWFsUHJvcHMgaXMgbm90IGNhbGxlZCBpbiBjYXNlIG9mXG4gICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3ZlcmNlbC9uZXh0LmpzL2lzc3Vlcy84NTkyLiBBcyBhIHdvcmthcm91bmQsIHdlIHBhc3NcbiAgICAvLyBlcnIgdmlhIF9hcHAuanMgc28gaXQgY2FuIGJlIGNhcHR1cmVkXG4gICAgU2VudHJ5LmNhcHR1cmVFeGNlcHRpb24oZXJyKTtcbiAgICAvLyBGbHVzaGluZyBpcyBub3QgcmVxdWlyZWQgaW4gdGhpcyBjYXNlIGFzIGl0IG9ubHkgaGFwcGVucyBvbiB0aGUgY2xpZW50XG4gIH1cblxuICByZXR1cm4gPE5leHRFcnJvckNvbXBvbmVudCBzdGF0dXNDb2RlPXtzdGF0dXNDb2RlfSAvPjtcbn07XG5cbk15RXJyb3IuZ2V0SW5pdGlhbFByb3BzID0gYXN5bmMgKGNvbnRleHQpID0+IHtcbiAgY29uc3QgZXJyb3JJbml0aWFsUHJvcHMgPSBhd2FpdCBOZXh0RXJyb3JDb21wb25lbnQuZ2V0SW5pdGlhbFByb3BzKGNvbnRleHQpO1xuXG4gIGNvbnN0IHsgcmVzLCBlcnIsIGFzUGF0aCB9ID0gY29udGV4dDtcblxuICAvLyBXb3JrYXJvdW5kIGZvciBodHRwczovL2dpdGh1Yi5jb20vdmVyY2VsL25leHQuanMvaXNzdWVzLzg1OTIsIG1hcmsgd2hlblxuICAvLyBnZXRJbml0aWFsUHJvcHMgaGFzIHJ1blxuICBlcnJvckluaXRpYWxQcm9wcy5oYXNHZXRJbml0aWFsUHJvcHNSdW4gPSB0cnVlO1xuXG4gIC8vIFJldHVybmluZyBlYXJseSBiZWNhdXNlIHdlIGRvbid0IHdhbnQgdG8gbG9nIDQwNCBlcnJvcnMgdG8gU2VudHJ5LlxuICBpZiAocmVzPy5zdGF0dXNDb2RlID09PSA0MDQpIHtcbiAgICByZXR1cm4gZXJyb3JJbml0aWFsUHJvcHM7XG4gIH1cblxuICAvLyBSdW5uaW5nIG9uIHRoZSBzZXJ2ZXIsIHRoZSByZXNwb25zZSBvYmplY3QgKGByZXNgKSBpcyBhdmFpbGFibGUuXG4gIC8vXG4gIC8vIE5leHQuanMgd2lsbCBwYXNzIGFuIGVyciBvbiB0aGUgc2VydmVyIGlmIGEgcGFnZSdzIGRhdGEgZmV0Y2hpbmcgbWV0aG9kc1xuICAvLyB0aHJldyBvciByZXR1cm5lZCBhIFByb21pc2UgdGhhdCByZWplY3RlZFxuICAvL1xuICAvLyBSdW5uaW5nIG9uIHRoZSBjbGllbnQgKGJyb3dzZXIpLCBOZXh0LmpzIHdpbGwgcHJvdmlkZSBhbiBlcnIgaWY6XG4gIC8vXG4gIC8vICAtIGEgcGFnZSdzIGBnZXRJbml0aWFsUHJvcHNgIHRocmV3IG9yIHJldHVybmVkIGEgUHJvbWlzZSB0aGF0IHJlamVjdGVkXG4gIC8vICAtIGFuIGV4Y2VwdGlvbiB3YXMgdGhyb3duIHNvbWV3aGVyZSBpbiB0aGUgUmVhY3QgbGlmZWN5Y2xlIChyZW5kZXIsXG4gIC8vICAgIGNvbXBvbmVudERpZE1vdW50LCBldGMpIHRoYXQgd2FzIGNhdWdodCBieSBOZXh0LmpzJ3MgUmVhY3QgRXJyb3JcbiAgLy8gICAgQm91bmRhcnkuIFJlYWQgbW9yZSBhYm91dCB3aGF0IHR5cGVzIG9mIGV4Y2VwdGlvbnMgYXJlIGNhdWdodCBieSBFcnJvclxuICAvLyAgICBCb3VuZGFyaWVzOiBodHRwczovL3JlYWN0anMub3JnL2RvY3MvZXJyb3ItYm91bmRhcmllcy5odG1sXG5cbiAgaWYgKGVycikge1xuICAgIFNlbnRyeS5jYXB0dXJlRXhjZXB0aW9uKGVycik7XG5cbiAgICAvLyBGbHVzaGluZyBiZWZvcmUgcmV0dXJuaW5nIGlzIG5lY2Vzc2FyeSBpZiBkZXBsb3lpbmcgdG8gVmVyY2VsLCBzZWVcbiAgICAvLyBodHRwczovL3ZlcmNlbC5jb20vZG9jcy9wbGF0Zm9ybS9saW1pdHMjc3RyZWFtaW5nLXJlc3BvbnNlc1xuICAgIGF3YWl0IFNlbnRyeS5mbHVzaCgyMDAwKTtcblxuICAgIHJldHVybiBlcnJvckluaXRpYWxQcm9wcztcbiAgfVxuXG4gIC8vIElmIHRoaXMgcG9pbnQgaXMgcmVhY2hlZCwgZ2V0SW5pdGlhbFByb3BzIHdhcyBjYWxsZWQgd2l0aG91dCBhbnlcbiAgLy8gaW5mb3JtYXRpb24gYWJvdXQgd2hhdCB0aGUgZXJyb3IgbWlnaHQgYmUuIFRoaXMgaXMgdW5leHBlY3RlZCBhbmQgbWF5XG4gIC8vIGluZGljYXRlIGEgYnVnIGludHJvZHVjZWQgaW4gTmV4dC5qcywgc28gcmVjb3JkIGl0IGluIFNlbnRyeVxuICBTZW50cnkuY2FwdHVyZUV4Y2VwdGlvbihcbiAgICBuZXcgRXJyb3IoYF9lcnJvci5qcyBnZXRJbml0aWFsUHJvcHMgbWlzc2luZyBkYXRhIGF0IHBhdGg6ICR7YXNQYXRofWApXG4gICk7XG4gIGF3YWl0IFNlbnRyeS5mbHVzaCgyMDAwKTtcblxuICByZXR1cm4gZXJyb3JJbml0aWFsUHJvcHM7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBNeUVycm9yO1xuIl0sIm5hbWVzIjpbIk5leHRFcnJvckNvbXBvbmVudCIsIlNlbnRyeSIsIk15RXJyb3IiLCJzdGF0dXNDb2RlIiwiaGFzR2V0SW5pdGlhbFByb3BzUnVuIiwiZXJyIiwiY2FwdHVyZUV4Y2VwdGlvbiIsImdldEluaXRpYWxQcm9wcyIsImNvbnRleHQiLCJlcnJvckluaXRpYWxQcm9wcyIsInJlcyIsImFzUGF0aCIsImZsdXNoIiwiRXJyb3IiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_error.js\n");

/***/ }),

/***/ "./sentry.server.config.js":
/*!*********************************!*\
  !*** ./sentry.server.config.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _sentry_nextjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @sentry/nextjs */ \"@sentry/nextjs\");\n/* harmony import */ var _sentry_nextjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sentry_nextjs__WEBPACK_IMPORTED_MODULE_0__);\n// This file configures the initialization of Sentry on the server.\n// The config you add here will be used whenever the server handles a request.\n// https://docs.sentry.io/platforms/javascript/guides/nextjs/\n\nconst SENTRY_DSN = process.env.SENTRY_DSN || process.env.NEXT_PUBLIC_SENTRY_DSN;\nif (SENTRY_DSN) {\n    _sentry_nextjs__WEBPACK_IMPORTED_MODULE_0__.init({\n        dsn: SENTRY_DSN,\n        // Adjust this value in production, or use tracesSampler for greater control\n        tracesSampleRate: 1\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zZW50cnkuc2VydmVyLmNvbmZpZy5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7QUFBQSxFQUFtRTtBQUNuRSxFQUE4RTtBQUM5RSxFQUE2RDtBQUVyQjtBQUV4QyxLQUFLLENBQUNDLFVBQVUsR0FBR0MsT0FBTyxDQUFDQyxHQUFHLENBQUNGLFVBQVUsSUFBSUMsT0FBTyxDQUFDQyxHQUFHLENBQUNDLHNCQUFzQjtBQUMvRSxFQUFFLEVBQUVILFVBQVUsRUFBRSxDQUFDO0lBQ2ZELGdEQUFXLENBQUMsQ0FBQztRQUNYTSxHQUFHLEVBQUVMLFVBQVU7UUFDZixFQUE0RTtRQUM1RU0sZ0JBQWdCLEVBQUUsQ0FBRztJQUt2QixDQUFDO0FBQ0gsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYi8uL3NlbnRyeS5zZXJ2ZXIuY29uZmlnLmpzPzc2MzAiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhpcyBmaWxlIGNvbmZpZ3VyZXMgdGhlIGluaXRpYWxpemF0aW9uIG9mIFNlbnRyeSBvbiB0aGUgc2VydmVyLlxuLy8gVGhlIGNvbmZpZyB5b3UgYWRkIGhlcmUgd2lsbCBiZSB1c2VkIHdoZW5ldmVyIHRoZSBzZXJ2ZXIgaGFuZGxlcyBhIHJlcXVlc3QuXG4vLyBodHRwczovL2RvY3Muc2VudHJ5LmlvL3BsYXRmb3Jtcy9qYXZhc2NyaXB0L2d1aWRlcy9uZXh0anMvXG5cbmltcG9ydCAqIGFzIFNlbnRyeSBmcm9tICdAc2VudHJ5L25leHRqcyc7XG5cbmNvbnN0IFNFTlRSWV9EU04gPSBwcm9jZXNzLmVudi5TRU5UUllfRFNOIHx8IHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NFTlRSWV9EU047XG5pZiAoU0VOVFJZX0RTTikge1xuICBTZW50cnkuaW5pdCh7XG4gICAgZHNuOiBTRU5UUllfRFNOLFxuICAgIC8vIEFkanVzdCB0aGlzIHZhbHVlIGluIHByb2R1Y3Rpb24sIG9yIHVzZSB0cmFjZXNTYW1wbGVyIGZvciBncmVhdGVyIGNvbnRyb2xcbiAgICB0cmFjZXNTYW1wbGVSYXRlOiAxLjAsXG4gICAgLy8gLi4uXG4gICAgLy8gTm90ZTogaWYgeW91IHdhbnQgdG8gb3ZlcnJpZGUgdGhlIGF1dG9tYXRpYyByZWxlYXNlIHZhbHVlLCBkbyBub3Qgc2V0IGFcbiAgICAvLyBgcmVsZWFzZWAgdmFsdWUgaGVyZSAtIHVzZSB0aGUgZW52aXJvbm1lbnQgdmFyaWFibGUgYFNFTlRSWV9SRUxFQVNFYCwgc29cbiAgICAvLyB0aGF0IGl0IHdpbGwgYWxzbyBnZXQgYXR0YWNoZWQgdG8geW91ciBzb3VyY2UgbWFwc1xuICB9KTtcbn1cbiJdLCJuYW1lcyI6WyJTZW50cnkiLCJTRU5UUllfRFNOIiwicHJvY2VzcyIsImVudiIsIk5FWFRfUFVCTElDX1NFTlRSWV9EU04iLCJpbml0IiwiZHNuIiwidHJhY2VzU2FtcGxlUmF0ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./sentry.server.config.js\n");

/***/ }),

/***/ "@sentry/nextjs":
/*!*********************************!*\
  !*** external "@sentry/nextjs" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@sentry/nextjs");

/***/ }),

/***/ "next/error":
/*!*****************************!*\
  !*** external "next/error" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/error");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./node_modules/@sentry/webpack-plugin/src/sentry-webpack.module.js"), __webpack_exec__("./sentry.server.config.js"), __webpack_exec__("./pages/_error.js"));
module.exports = __webpack_exports__;

})();