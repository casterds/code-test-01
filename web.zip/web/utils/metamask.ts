import detectEthereumProvider from '@metamask/detect-provider';
import { ethers,Signer } from 'ethers';
import config from 'utils/config';
import { useAccount } from 'store/account';
import { Masa } from "@masa-finance/masa-sdk";
import { sign } from 'crypto';


/**
 * Gets metamask client.
 */
export async function getMetamask(): Promise<any> {
  return await detectEthereumProvider();
}

/**
 * Gets the ethers client.
 */
export async function getEthers(): Promise<ethers.providers.Web3Provider | null> {
  const metamask = await getMetamask();
  if (!metamask) {
    return null;
  }
  return new ethers.providers.Web3Provider(metamask);
}

export async function getSigner() {
  const metamask = await getMetamask();
  if (!metamask) {
    return null;
  }
  
  const provider = new ethers.providers.Web3Provider(metamask);
  const signer = provider.getSigner() as ethers.providers.JsonRpcSigner ;
  const masa = new Masa({
    signer,
  });
  return signer;
}




/**
 * Gets the contract client.
 */
export async function getContract(): Promise<ethers.Contract | null> {
  const eth = await getEthers();
  if (!eth) {
    return null;
  }

  const network = useAccount.getState().network;
  const contractAddress =
    network === 'mainnet'
      ? config.MAINNET_CONTRACT_ADDRESS
      : config.TESTNET_CONTRACT_ADDRESS;

  const signer = eth.getSigner();
  return new ethers.Contract(contractAddress, config.CONTRACT_ABI, signer);
}
